# Introduction 
YT-to-Spot is a firefox extension that takes in the url of a music video hosted on Youtube and opens a new tab containing the link to the same song hosted on Spotify. 
This is a surprising common task for me, and I wanted to automate this process to make a bit painless.
This uses the Spotify API and Youtube API to get the title of the youtube video and search it on Spotify API. 

# Usage

Open the 
